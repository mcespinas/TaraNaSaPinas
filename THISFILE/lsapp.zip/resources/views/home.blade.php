@extends('layouts.template')
@section('title') - Home @endsection
@section('header') TaraNaSaPinas @endsection
@section('subheader')  @endsection

@section('style')

@endsection

@section('script')

@endsection

@section('content')

@endsection