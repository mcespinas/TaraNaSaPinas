@extends('layouts.template')
@section('title') -  @endsection
@section('header')  @endsection
@section('subheader')  @endsection

@section('style')

@endsection

@section('script')

@endsection

@section('content')

@endsection