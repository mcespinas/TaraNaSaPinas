@extends('layouts.template')
@section('title') - Edit Profile @endsection
@section('header') Edit Profile @endsection
@section('subheader')  @endsection

@section('style')

@endsection

@section('script')

@endsection

@section('content')
    {!! Form::open(['action' => ['AgencyController@update', $agency->id], 'method' => 'POST', 'enctype' => 'multipart/form-data'])!!}
        @if (Auth::user()->user_type == 'System Administrator')
            <div class="form-group">
                {{Form::label('agency_status', 'Registration Status')}}
                {{Form::text('agency_status', $agency->agency_status, ['class' => 'form-control'])}}
            </div>

            <div class="form-group">
                {{Form::label('agency_name', 'Company Name')}}
                {{Form::text('agency_name', $agency->agency_name, ['class' => 'form-control'])}}
            </div>    
            <div class="form-group">
                {{Form::label('agency_address', 'Address')}}
                {{Form::text('agency_address', $agency->agency_address, ['class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('agency_contact', 'Contact Number')}}
                {{Form::text('agency_contact', $agency->agency_contact, ['class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('agency_email', 'Email Address')}}
                {{Form::text('agency_email', $agency->agency_email, ['class' => 'form-control'])}}
            </div>        
            <div class="form-group">
                {{Form::label('agency_permit', 'Business Permit Number')}}
                {{Form::text('agency_permit', $agency->agency_permit, ['class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('agency_info', 'Additional Details')}}
                {{Form::textarea('agency_info', $agency->agency_info, ['id' => 'article-ckeditor', 'class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('agency_url', 'Website URL')}}
                {{Form::text('agency_url', $agency->agency_url, ['class' => 'form-control'])}}
            </div>

            {{Form::hidden('agency_logo', $agency->agency_logo)}}
        @endif

        @if (Auth::user()->user_type == 'Travel Agency')
            {{Form::hidden('agency_status', $agency->agency_status)}}

            <div class="form-group">
                {{Form::label('agency_name', 'Company Name')}}
                {{Form::text('agency_name', $agency->agency_name, ['class' => 'form-control'])}}
            </div>    
            <div class="form-group">
                {{Form::label('agency_address', 'Address')}}
                {{Form::text('agency_address', $agency->agency_address, ['class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('agency_contact', 'Contact Number')}}
                {{Form::text('agency_contact', $agency->agency_contact, ['class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('agency_email', 'Email Address')}}
                {{Form::text('agency_email', $agency->agency_email, ['class' => 'form-control'])}}
            </div>        
            <div class="form-group">
                {{Form::label('agency_permit', 'Business Permit Number')}}
                {{Form::text('agency_permit', $agency->agency_permit, ['class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('agency_info', 'Additional Details')}}
                {{Form::textarea('agency_info', $agency->agency_info, ['id' => 'article-ckeditor', 'class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('agency_url', 'Website URL')}}
                {{Form::text('agency_url', $agency->agency_url, ['class' => 'form-control'])}}
            </div>

            @if ($agency->agency_logo != "no_image.png")
                <div class="form-group">
                    <label>Company Logo</label>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <img src="http://localhost/lsapp/public/storage/agency_logos/{!!$agency->agency_logo!!}" />
                    </div>
                </div>
            @endif

            <div class="upload-btn-wrapper">
                {{Form::file('agency_logo')}}
            </div><br />
        @endif

        {{Form::hidden('_method', 'PUT')}} 
        {{Form::submit('Submit', ['class' => 'btn btn-info'])}}
        <a href="/lsapp/public/agencies" class="btn btn-info pull-right">Cancel</a>
    {!! Form::close() !!}
@endsection