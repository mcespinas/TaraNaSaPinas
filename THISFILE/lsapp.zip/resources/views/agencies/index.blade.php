@extends('layouts.template')
@section('title') - View Agencies @endsection
@section('header') View Agencies @endsection
@section('subheader')  @endsection

@section('style')

@endsection

@section('script')

@endsection

@section('content')
    <div class="card-content table-responsive">
        @if(count($agencies) > 0)
            <table class="table">
                <thead class="text-info">
                    <th>Agency Name</th>
                    @if (Auth::user()->user_type == 'Travel Agency')
                        <th>Address</th>
                        <th>Contact Number</th>
                        <th>Email Address</th>
                    @endif
                    @if (Auth::user()->user_type == 'System Administrator')
                        <th>Account Status</th>
                        <th>Business Permit Number</th>
                        <th>Rating</th>
                        <th></th>
                        <th></th>
                    @endif    
                </thead>
                <tbody>
                    @foreach($agencies as $agency)
                        <tr>
                            @if (Auth::user()->user_type == 'Travel Agency')
                                <td>
                                    @if (Auth::user()->id == $agency->id)
                                        <a href="/lsapp/public/agencies/{{$agency->id}}">
                                            {{$agency->agency_name}}
                                        </a>
                                    @else
                                    <a href="http://{{$agency->agency_url}}">
                                        {{$agency->agency_name}}
                                    </a>
                                    @endif    
                                </td>
                                <td>{{$agency->agency_address}}</td>
                                <td>{{$agency->agency_contact}}</td>
                                <td>{{$agency->agency_email}}</td>
                            @endif
                            @if (Auth::user()->user_type == 'System Administrator')
                                <td><a href="/lsapp/public/agencies/{{$agency->id}}">{{$agency->agency_name}}</a></td>
                                <td>{{$agency->agency_status}}</td>
                                <td>{{$agency->agency_permit}}</td>
                                <td>
                                    @if (($agency->agency_rating >= 0.00) && ($agency->agency_rating <= 0.49))
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    @endif

                                    @if (($agency->agency_rating > 0.49) && ($agency->agency_rating <= 1.49))
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    @endif
                                    
                                    @if (($agency->agency_rating > 1.49) && ($agency->agency_rating <= 2.49))
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    @endif

                                    @if (($agency->agency_rating > 2.49) && ($agency->agency_rating <= 3.49))
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    @endif

                                    @if (($agency->agency_rating > 3.49) && ($agency->agency_rating <= 4.49))
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star"></span>
                                    @endif

                                    @if (($agency->agency_rating > 4.49) && ($agency->agency_rating <= 5.00))
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                    @endif
                                </td> 
                                <td>
                                    <a href="/lsapp/public/agencies/{{$agency->id}}/edit" class="btn btn-info">
                                        <i class="material-icons">create</i>
                                    </a>
                                </td>
                                <td>
                                    {!!Form::open(['action' => ['AgencyController@destroy', $agency->id], 'method' => 'POST'])!!}
                                        {{Form::hidden('_method', 'DELETE')}}
                                        <button type="submit" class="btn btn-danger">
                                            <i class="material-icons">delete</i>
                                        </button>
                                    {!!Form::close()!!} 
                                </td>
                            @endif
                        </tr>
                    @endforeach    
                </tbody>
            </table>
        @else
            <p>No travel agencies found.</p>
        @endif
    </div>
@endsection