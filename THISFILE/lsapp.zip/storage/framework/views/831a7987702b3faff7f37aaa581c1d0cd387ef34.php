<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>"/>
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">  

    <!-- Fonts and icons -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />

    <!-- Datepicker
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css">
    -->

    <!-- Title -->
    <title><?php echo e(config('app.name', 'TaraNaSaPinas')); ?> <?php echo $__env->yieldContent('title'); ?></title>

</head>
<body>
    <div id="app">
        <?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="container"> 
            <main class="py-4">
                <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div> 
    </div>

    <!-- Core JS Files -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <!-- Datepicker JS Files
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>

    <script type="text/javascript">  
        $('#datepicker1').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'  
         });
         $('#datepicker2').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'  
         });
         $('#datepicker3').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'  
         });
         $('#datepicker4').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'  
         });
         $('#datepicker5').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'  
         });
         $('#datepicker6').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'  
         });
         $('#datepicker7').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'  
         });
         $('#datepicker8').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'  
         });  
    </script> 
    -->

    <!-- Text Editor JS Files -->
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'article-ckeditor' );
    </script>
</body>
</html>
