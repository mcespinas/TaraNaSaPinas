<?php $__env->startSection('title'); ?> - Edit Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?> Edit Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('subheader'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['action' => ['AgencyController@update', $agency->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <?php if(Auth::user()->user_type == 'System Administrator'): ?>
            <div class="form-group">
                <?php echo e(Form::label('agency_status', 'Registration Status')); ?>

                <?php echo e(Form::text('agency_status', $agency->agency_status, ['class' => 'form-control'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::label('agency_name', 'Company Name')); ?>

                <?php echo e(Form::text('agency_name', $agency->agency_name, ['class' => 'form-control'])); ?>

            </div>    
            <div class="form-group">
                <?php echo e(Form::label('agency_address', 'Address')); ?>

                <?php echo e(Form::text('agency_address', $agency->agency_address, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('agency_contact', 'Contact Number')); ?>

                <?php echo e(Form::text('agency_contact', $agency->agency_contact, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('agency_email', 'Email Address')); ?>

                <?php echo e(Form::text('agency_email', $agency->agency_email, ['class' => 'form-control'])); ?>

            </div>        
            <div class="form-group">
                <?php echo e(Form::label('agency_permit', 'Business Permit Number')); ?>

                <?php echo e(Form::text('agency_permit', $agency->agency_permit, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('agency_info', 'Additional Details')); ?>

                <?php echo e(Form::textarea('agency_info', $agency->agency_info, ['id' => 'article-ckeditor', 'class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('agency_url', 'Website URL')); ?>

                <?php echo e(Form::text('agency_url', $agency->agency_url, ['class' => 'form-control'])); ?>

            </div>

            <?php echo e(Form::hidden('agency_logo', $agency->agency_logo)); ?>

        <?php endif; ?>

        <?php if(Auth::user()->user_type == 'Travel Agency'): ?>
            <?php echo e(Form::hidden('agency_status', $agency->agency_status)); ?>


            <div class="form-group">
                <?php echo e(Form::label('agency_name', 'Company Name')); ?>

                <?php echo e(Form::text('agency_name', $agency->agency_name, ['class' => 'form-control'])); ?>

            </div>    
            <div class="form-group">
                <?php echo e(Form::label('agency_address', 'Address')); ?>

                <?php echo e(Form::text('agency_address', $agency->agency_address, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('agency_contact', 'Contact Number')); ?>

                <?php echo e(Form::text('agency_contact', $agency->agency_contact, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('agency_email', 'Email Address')); ?>

                <?php echo e(Form::text('agency_email', $agency->agency_email, ['class' => 'form-control'])); ?>

            </div>        
            <div class="form-group">
                <?php echo e(Form::label('agency_permit', 'Business Permit Number')); ?>

                <?php echo e(Form::text('agency_permit', $agency->agency_permit, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('agency_info', 'Additional Details')); ?>

                <?php echo e(Form::textarea('agency_info', $agency->agency_info, ['id' => 'article-ckeditor', 'class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('agency_url', 'Website URL')); ?>

                <?php echo e(Form::text('agency_url', $agency->agency_url, ['class' => 'form-control'])); ?>

            </div>

            <?php if($agency->agency_logo != "no_image.png"): ?>
                <div class="form-group">
                    <label>Company Logo</label>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <img src="http://localhost/lsapp/public/storage/agency_logos/<?php echo $agency->agency_logo; ?>" />
                    </div>
                </div>
            <?php endif; ?>

            <div class="upload-btn-wrapper">
                <?php echo e(Form::file('agency_logo')); ?>

            </div><br />
        <?php endif; ?>

        <?php echo e(Form::hidden('_method', 'PUT')); ?> 
        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-info'])); ?>

        <a href="/lsapp/public/agencies" class="btn btn-info pull-right">Cancel</a>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>