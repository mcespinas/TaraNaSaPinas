<?php $__env->startSection('title'); ?> - Company Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?> Company Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('subheader'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-2">    
            <img src='http://localhost/lsapp/public/storage/agency_logos/<?php echo $agency->agency_logo; ?>'>
        </div>
    </div>
    
    <h1 class="category text-black">
        <a href="http://<?php echo $agency->agency_url; ?>">
            <?php echo $agency->agency_name; ?>

        </a>
    </h1>                          
    <h4> 
        Application Status: 
        <b> <?php echo $agency->agency_status; ?> </b> 
    </h4><br />
    <h4>
        Address:
        <b> <?php echo $agency->agency_address; ?> </b>
    </h4>
    <h4>
        Contact Number:
        <b> <?php echo $agency->agency_contact; ?> </b>
    </h4>
    <h4>
        Email Address:
        <b> <?php echo $agency->agency_email; ?> </b>
    </h4>
    <h4>
        Business Permit Number:
        <b> <?php echo $agency->agency_permit; ?> </b>
    </h4>
                                            
    <br /><h4>
        About Us:<br />
        <?php echo $agency->agency_info; ?>

    </h4><br />

    <h4>
        User Rating:
        <?php if(($agency->agency_rating >= 0.00) && ($agency->agency_rating <= 0.49)): ?>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
        <?php endif; ?>

        <?php if(($agency->agency_rating > 0.49) && ($agency->agency_rating <= 1.49)): ?>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
        <?php endif; ?>
                                                
        <?php if(($agency->agency_rating > 1.49) && ($agency->agency_rating <= 2.49)): ?>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
        <?php endif; ?>

        <?php if(($agency->agency_rating > 2.49) && ($agency->agency_rating <= 3.49)): ?>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
        <?php endif; ?>

        <?php if(($agency->agency_rating > 3.49) && ($agency->agency_rating <= 4.49)): ?>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
        <?php endif; ?>

        <?php if(($agency->agency_rating > 4.49) && ($agency->agency_rating <= 5.00)): ?>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
        <?php endif; ?>
    </h4>        
    <table>
        <td width=100>
            <a href="/lsapp/public/agencies/<?php echo e($agency->id); ?>/edit" class="btn btn-info btn-block">Edit</a>
        </td>
        <?php if(Auth::user()->user_type == 'System Administrator'): ?>
            <td width=25>&nbsp;</td>    
            <td width=100>
                <?php echo Form::open(['action' => ['AgencyController@destroy', $agency->id], 'method' => 'POST']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger btn-block'])); ?>

                <?php echo Form::close(); ?> 
            </td>
        <?php endif; ?>            
    </table> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>