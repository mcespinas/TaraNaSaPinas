<?php $__env->startSection('url'); ?>  <?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?> - Create Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?> Create Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('subheader'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['action' => 'AgencyController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('agency_name', 'Company Name')); ?>

            <?php echo e(Form::text('agency_name', '', ['class' => 'form-control'])); ?>

        </div>    
        <div class="form-group">
            <?php echo e(Form::label('agency_address', 'Address')); ?>

            <?php echo e(Form::text('agency_address', '', ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('agency_contact', 'Contact Number')); ?>

            <?php echo e(Form::text('agency_contact', '', ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('agency_email', 'Email Address')); ?>

            <?php echo e(Form::text('agency_email', '', ['class' => 'form-control'])); ?>

        </div>        
        <div class="form-group">
            <?php echo e(Form::label('agency_permit', 'Business Permit Number')); ?>

            <?php echo e(Form::text('agency_permit', '', ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('agency_info', 'Additional Details')); ?>

            <?php echo e(Form::textarea('agency_info', '', ['id' => 'article-ckeditor-agency-info', 'class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('agency_url', 'Website URL')); ?>

            <?php echo e(Form::text('agency_url', '', ['class' => 'form-control'])); ?>

        </div> 

        <div class="form-group">
            <label>Company Logo</label>
        </div>
        <div class="upload-btn-wrapper">
            <?php echo e(Form::file('agency_logo')); ?>

        </div><br />

        <?php echo e(Form::hidden('agency_status', 'Pending')); ?>

        <?php echo e(Form::hidden('agency_rating', 0)); ?>  

        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-info'])); ?>

        <a href="/lsapp/public/agencies/" class="btn btn-info pull-right">Cancel</a>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>