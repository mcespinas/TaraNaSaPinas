<?php $__env->startSection('title'); ?> - Home <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?> TaraNaSaPinas <?php $__env->stopSection(); ?>
<?php $__env->startSection('subheader'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>