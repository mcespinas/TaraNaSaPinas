<?php $__env->startSection('title'); ?> - View Agencies <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?> View Agencies <?php $__env->stopSection(); ?>
<?php $__env->startSection('subheader'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-content table-responsive">
        <?php if(count($agencies) > 0): ?>
            <table class="table">
                <thead class="text-info">
                    <th>Agency Name</th>
                    <?php if(Auth::user()->user_type == 'Travel Agency'): ?>
                        <th>Address</th>
                        <th>Contact Number</th>
                        <th>Email Address</th>
                    <?php endif; ?>
                    <?php if(Auth::user()->user_type == 'System Administrator'): ?>
                        <th>Account Status</th>
                        <th>Business Permit Number</th>
                        <th>Rating</th>
                        <th></th>
                        <th></th>
                    <?php endif; ?>    
                </thead>
                <tbody>
                    <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if(Auth::user()->user_type == 'Travel Agency'): ?>
                                <td>
                                    <?php if(Auth::user()->id == $agency->id): ?>
                                        <a href="/lsapp/public/agencies/<?php echo e($agency->id); ?>">
                                            <?php echo e($agency->agency_name); ?>

                                        </a>
                                    <?php else: ?>
                                    <a href="http://<?php echo e($agency->agency_url); ?>">
                                        <?php echo e($agency->agency_name); ?>

                                    </a>
                                    <?php endif; ?>    
                                </td>
                                <td><?php echo e($agency->agency_address); ?></td>
                                <td><?php echo e($agency->agency_contact); ?></td>
                                <td><?php echo e($agency->agency_email); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->user_type == 'System Administrator'): ?>
                                <td><a href="/lsapp/public/agencies/<?php echo e($agency->id); ?>"><?php echo e($agency->agency_name); ?></a></td>
                                <td><?php echo e($agency->agency_status); ?></td>
                                <td><?php echo e($agency->agency_permit); ?></td>
                                <td>
                                    <?php if(($agency->agency_rating >= 0.00) && ($agency->agency_rating <= 0.49)): ?>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    <?php endif; ?>

                                    <?php if(($agency->agency_rating > 0.49) && ($agency->agency_rating <= 1.49)): ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    <?php endif; ?>
                                    
                                    <?php if(($agency->agency_rating > 1.49) && ($agency->agency_rating <= 2.49)): ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    <?php endif; ?>

                                    <?php if(($agency->agency_rating > 2.49) && ($agency->agency_rating <= 3.49)): ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    <?php endif; ?>

                                    <?php if(($agency->agency_rating > 3.49) && ($agency->agency_rating <= 4.49)): ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star"></span>
                                    <?php endif; ?>

                                    <?php if(($agency->agency_rating > 4.49) && ($agency->agency_rating <= 5.00)): ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                    <?php endif; ?>
                                </td> 
                                <td>
                                    <a href="/lsapp/public/agencies/<?php echo e($agency->id); ?>/edit" class="btn btn-info">
                                        <i class="material-icons">create</i>
                                    </a>
                                </td>
                                <td>
                                    <?php echo Form::open(['action' => ['AgencyController@destroy', $agency->id], 'method' => 'POST']); ?>

                                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                        <button type="submit" class="btn btn-danger">
                                            <i class="material-icons">delete</i>
                                        </button>
                                    <?php echo Form::close(); ?> 
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </tbody>
            </table>
        <?php else: ?>
            <p>No travel agencies found.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>