<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>"/>

	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href=" <?php echo e(asset('css/bootstrap.min.css')); ?>" />
	<link rel="stylesheet" href=" <?php echo e(asset('css/paper-kit.css')); ?>" />

	<!-- Fonts and icons -->
	<link rel="stylesheet" href='http://fonts.googleapis.com/css?family=Montserrat:400,300,700' type='text/css'>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
	<link rel="stylesheet" href=" <?php echo e(asset('css/nucleo-icons.css')); ?>" />

    <!-- Title -->
    <title><?php echo e(config('app.name', 'TaraNaSaPinas')); ?></title>
</head>
<body>
    <nav class="navbar navbar-expand-md fixed-top navbar-transparent">
        <div class="container">
			<div class="navbar-translate">
	            <a class="navbar-brand"href="<?php echo e(url('/')); ?>">TaraNaSaPinas</a>
            </div>
            
			<div class="collapse navbar-collapse" id="navbarToggler">
	            <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="<?php echo e(route('login')); ?>" class="nav-link">Login</a>
                    </li>
					<li class="nav-item">
	                    <a href="<?php echo e(route('register')); ?>" class="nav-link">Register</a>
	                </li>
	            </ul>
	        </div>
		</div>
    </nav>
    <div class="wrapper">
        <div class="page-header" style="background-image: url('<?php echo e(asset('img/welcome_page_1280.jpg')); ?>');">
            <div class="filter"></div>

                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 ml-auto mr-auto">
                            <div class="card card-register">

                                <img src="<?php echo e(asset('img/logo.png')); ?>" height="200" width="300"/>
                                
                                <h3 class="title">Login</h3>

                                <form class="register-form">
                                    <label>Email</label>
                                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>

                                    <label>Password</label>
                                    <input type="password" class="form-control" placeholder="Password">
                                    <button class="btn btn-danger btn-block btn-round">Register</button>
                                </form>
                                <div class="forgot">
                                    <a href="#" class="btn btn-link btn-danger">Forgot password?</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</body>

<!-- Core JS Files -->
<script type="text/javascript" src="<?php echo e(asset('js/jquery-3.2.1.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-ui-1.12.1.custom.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/tether.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<!--  Paper Kit Initialization snd functons -->
<script src="<?php echo e(asset('js/paper-kit.js?v=2.0.1')); ?>"></script>

</html>