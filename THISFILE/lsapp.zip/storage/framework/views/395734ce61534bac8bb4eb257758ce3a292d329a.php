<div class="wrapper">
<div class="page-header" style="background-image: url('<?php echo e(asset('img/welcome_page_1280.jpg')); ?>');">
</div>
</div>